// Часовой пояс отображения. Для MVP фиксирован; позже сделаем выбор в профиле.
export const TZ = 'Europe/Tallinn';
export const fmt = (iso: string) =>
  new Date(iso).toLocaleString('ru-RU', { dateStyle: 'medium', timeStyle: 'short', timeZone: TZ });
