-- 5school, этап 4: планы уроков и домашка. Выполнить ПОСЛЕ schema_stage3.sql.
alter table lessons add column plan text not null default '' check (char_length(plan) <= 4000);

create table homework (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references lessons on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  body text not null default '' check (char_length(body) <= 4000),
  status text not null default 'assigned' check (status in ('assigned', 'submitted', 'checked')),
  answer text not null default '' check (char_length(answer) <= 4000),
  feedback text not null default '' check (char_length(feedback) <= 4000),
  created_at timestamptz not null default now()
);
alter table homework enable row level security;

-- Видят домашку только участники урока
create policy "homework: видят участники урока" on homework for select using (
  exists (select 1 from lessons l where l.id = homework.lesson_id and (l.student_id = auth.uid() or l.tutor_id = auth.uid()))
);
-- Задаёт и удаляет только репетитор этого урока
create policy "homework: репетитор задаёт" on homework for insert with check (
  exists (select 1 from lessons l where l.id = homework.lesson_id and l.tutor_id = auth.uid())
);
create policy "homework: репетитор удаляет" on homework for delete using (
  exists (select 1 from lessons l where l.id = homework.lesson_id and l.tutor_id = auth.uid())
);

-- Ответ и проверку меняем только через функции, чтобы ученик не мог поставить себе "проверено"
revoke update on homework from authenticated;

create or replace function submit_homework(p_id uuid, p_answer text) returns void
language plpgsql security definer set search_path = public as $$
begin
  update homework h set answer = left(p_answer, 4000), status = 'submitted'
  from lessons l
  where h.id = p_id and l.id = h.lesson_id and l.student_id = auth.uid() and h.status = 'assigned';
  if not found then raise exception 'not_allowed'; end if;
end $$;

create or replace function check_homework(p_id uuid, p_feedback text) returns void
language plpgsql security definer set search_path = public as $$
begin
  update homework h set feedback = left(p_feedback, 4000), status = 'checked'
  from lessons l
  where h.id = p_id and l.id = h.lesson_id and l.tutor_id = auth.uid() and h.status = 'submitted';
  if not found then raise exception 'not_allowed'; end if;
end $$;

grant execute on function submit_homework(uuid, text) to authenticated;
grant execute on function check_homework(uuid, text) to authenticated;
