-- 5school, этап 5а: подписка репетитора. Выполнить ПОСЛЕ schema_stage4.sql.
-- Записи в subscriptions меняет только сервер (вебхук провайдера), пользователям записи запрещены.
create table subscriptions (
  id uuid primary key default gen_random_uuid(),
  tutor_id uuid not null unique references tutor_profiles on delete cascade,
  status text not null default 'inactive' check (status in ('inactive', 'trialing', 'active', 'past_due', 'canceled')),
  current_period_end timestamptz,
  provider_ref text,
  updated_at timestamptz not null default now()
);
alter table subscriptions enable row level security;
create policy "subscriptions: видит владелец" on subscriptions for select using (auth.uid() = tutor_id);

-- Доступ есть, пока оплачен текущий период. При просрочке платежа (past_due) доступа нет.
create or replace function tutor_has_access(p_tutor uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from subscriptions s
    where s.tutor_id = p_tutor
      and s.status in ('trialing', 'active', 'canceled')
      and s.current_period_end > now()
  );
$$;

-- Без подписки анкета скрыта из каталога, слоты не видны и не добавляются
drop policy if exists "tutors: видны опубликованные" on tutor_profiles;
create policy "tutors: видны опубликованные" on tutor_profiles for select
  using ((is_published and tutor_has_access(id)) or auth.uid() = id);

drop policy if exists "slots: читают все" on availability;
create policy "slots: читают" on availability for select
  using (tutor_has_access(tutor_id) or auth.uid() = tutor_id);

drop policy if exists "slots: репетитор добавляет" on availability;
create policy "slots: репетитор добавляет" on availability for insert
  with check (auth.uid() = tutor_id and starts_at > now() and tutor_has_access(auth.uid()));

-- Запись на урок теперь проверяет подписку репетитора
create or replace function book_lesson(p_tutor uuid, p_starts timestamptz)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_lesson uuid;
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if not exists (select 1 from profiles where id = auth.uid() and role = 'student') then
    raise exception 'only_students_can_book';
  end if;
  if not tutor_has_access(p_tutor) then raise exception 'tutor_inactive'; end if;
  delete from availability where tutor_id = p_tutor and starts_at = p_starts;
  if not found then raise exception 'slot_taken'; end if;
  insert into lessons (tutor_id, student_id, starts_at) values (p_tutor, auth.uid(), p_starts)
  returning id into v_lesson;
  return v_lesson;
end $$;

-- Тестовая подписка (только в SQL Editor, для проверки доступа без оплаты):
-- insert into subscriptions (tutor_id, status, current_period_end)
-- values ('<uuid репетитора>', 'active', now() + interval '30 days');

-- После закрытия подписки репетитор видит историю своих уроков, отзывы и анкету,
-- но не может работать с учениками: ставить и проверять домашку, менять планы, отмечать уроки.
drop policy if exists "homework: репетитор задаёт" on homework;
create policy "homework: репетитор задаёт" on homework for insert
  with check (tutor_has_access(auth.uid()) and exists (
    select 1 from lessons l where l.id = homework.lesson_id and l.tutor_id = auth.uid()));

drop policy if exists "homework: репетитор удаляет" on homework;
create policy "homework: репетитор удаляет" on homework for delete
  using (tutor_has_access(auth.uid()) and exists (
    select 1 from lessons l where l.id = homework.lesson_id and l.tutor_id = auth.uid()));

drop policy if exists "lessons: репетитор отмечает итог" on lessons;
create policy "lessons: репетитор отмечает итог" on lessons for update
  using (auth.uid() = tutor_id and tutor_has_access(auth.uid()))
  with check (auth.uid() = tutor_id and tutor_has_access(auth.uid()));

create or replace function check_homework(p_id uuid, p_feedback text) returns void
language plpgsql security definer set search_path = public as $$
begin
  update homework h set feedback = left(p_feedback, 4000), status = 'checked'
  from lessons l
  where h.id = p_id and l.id = h.lesson_id and l.tutor_id = auth.uid()
    and h.status = 'submitted' and tutor_has_access(auth.uid());
  if not found then raise exception 'not_allowed'; end if;
end $$;
