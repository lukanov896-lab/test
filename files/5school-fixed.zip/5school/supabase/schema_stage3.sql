-- 5school, этап 3: расписание, запись и фото. Выполнить ПОСЛЕ schema.sql.
create table availability (
  id uuid primary key default gen_random_uuid(),
  tutor_id uuid not null references tutor_profiles on delete cascade,
  starts_at timestamptz not null,
  created_at timestamptz not null default now(),
  unique (tutor_id, starts_at)
);
alter table availability enable row level security;
create policy "slots: читают все" on availability for select using (true);
create policy "slots: репетитор добавляет" on availability for insert
  with check (auth.uid() = tutor_id and starts_at > now());
create policy "slots: репетитор удаляет свои" on availability for delete
  using (auth.uid() = tutor_id);

-- Запись одним действием: слот удаляется и создаётся урок
create or replace function book_lesson(p_tutor uuid, p_starts timestamptz)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_lesson uuid;
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if not exists (select 1 from profiles where id = auth.uid() and role = 'student') then
    raise exception 'only_students_can_book';
  end if;
  delete from availability where tutor_id = p_tutor and starts_at = p_starts;
  if not found then raise exception 'slot_taken'; end if;
  insert into lessons (tutor_id, student_id, starts_at) values (p_tutor, auth.uid(), p_starts)
  returning id into v_lesson;
  return v_lesson;
end $$;
revoke execute on function book_lesson(uuid, timestamptz) from public;
grant execute on function book_lesson(uuid, timestamptz) to authenticated;

-- Фото репетиторов: публичное чтение, загрузка только в свою папку
insert into storage.buckets (id, name, public) values ('tutor-photos', 'tutor-photos', true)
  on conflict (id) do nothing;
create policy "photos: читают все" on storage.objects for select
  using (bucket_id = 'tutor-photos');
create policy "photos: загружает владелец" on storage.objects for insert to authenticated
  with check (bucket_id = 'tutor-photos' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "photos: удаляет владелец" on storage.objects for delete to authenticated
  using (bucket_id = 'tutor-photos' and (storage.foldername(name))[1] = auth.uid()::text);
