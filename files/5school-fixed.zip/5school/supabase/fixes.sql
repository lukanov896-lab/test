-- 5school: исправления для уже созданной базы. Выполнить в SQL Editor один раз.
create or replace function refresh_rating() returns trigger language plpgsql security definer set search_path = public as $$
begin
  update tutor_profiles t set
    rating_count = (select count(*) from reviews r where r.tutor_id = t.id),
    rating_avg = coalesce((select round(avg(r.rating), 1) from reviews r where r.tutor_id = t.id), 0)
  where t.id = coalesce(new.tutor_id, old.tutor_id);
  return null;
end $$;

-- Пересчитать рейтинг уже существующих анкет
update tutor_profiles t set
  rating_count = (select count(*) from reviews r where r.tutor_id = t.id),
  rating_avg = coalesce((select round(avg(r.rating), 1) from reviews r where r.tutor_id = t.id), 0);

create or replace function check_homework(p_id uuid, p_feedback text) returns void
language plpgsql security definer set search_path = public as $$
begin
  update homework h set feedback = left(p_feedback, 4000), status = 'checked'
  from lessons l
  where h.id = p_id and l.id = h.lesson_id and l.tutor_id = auth.uid() and h.status = 'submitted';
  if not found then raise exception 'not_allowed'; end if;
end $$;
