-- 5school: схема базы. Вставить в Supabase → SQL Editor и выполнить целиком.
create type user_role as enum ('student', 'tutor');

create table profiles (
  id uuid primary key references auth.users on delete cascade,
  role user_role not null,
  full_name text not null,
  created_at timestamptz not null default now()
);

create table tutor_profiles (
  id uuid primary key references profiles on delete cascade,
  headline text not null default '',
  bio text not null default '',
  subjects text[] not null default '{}',
  price_per_hour integer not null default 0 check (price_per_hour >= 0),
  currency text not null default 'EUR',
  photos text[] not null default '{}',
  rating_avg numeric(2,1) not null default 0,
  rating_count integer not null default 0,
  is_published boolean not null default false,
  updated_at timestamptz not null default now()
);

create table lessons (
  id uuid primary key default gen_random_uuid(),
  tutor_id uuid not null references tutor_profiles on delete cascade,
  student_id uuid not null references profiles on delete cascade,
  starts_at timestamptz not null,
  status text not null default 'scheduled' check (status in ('scheduled', 'completed', 'cancelled')),
  created_at timestamptz not null default now()
);

create table reviews (
  id uuid primary key default gen_random_uuid(),
  tutor_id uuid not null references tutor_profiles on delete cascade,
  student_id uuid not null references profiles on delete cascade,
  rating smallint not null check (rating between 1 and 5),
  body text not null default '' check (char_length(body) <= 1000),
  created_at timestamptz not null default now(),
  unique (tutor_id, student_id)
);

-- Общая оценка пересчитывается при каждом изменении отзывов
create or replace function refresh_rating() returns trigger language plpgsql security definer set search_path = public as $$
begin
  update tutor_profiles t set
    rating_count = (select count(*) from reviews r where r.tutor_id = t.id),
    rating_avg = coalesce((select round(avg(r.rating), 1) from reviews r where r.tutor_id = t.id), 0)
  where t.id = coalesce(new.tutor_id, old.tutor_id);
  return null;
end $$;
create trigger reviews_rating after insert or update or delete on reviews
  for each row execute function refresh_rating();

-- При регистрации создаём профиль; роль и имя берём из metadata
create or replace function handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, role, full_name)
  values (
    new.id,
    coalesce((new.raw_user_meta_data->>'role')::user_role, 'student'),
    coalesce(new.raw_user_meta_data->>'full_name', 'Пользователь')
  );
  if new.raw_user_meta_data->>'role' = 'tutor' then
    insert into tutor_profiles (id) values (new.id);
  end if;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- Безопасность (RLS)
alter table profiles enable row level security;
alter table tutor_profiles enable row level security;
alter table lessons enable row level security;
alter table reviews enable row level security;

create policy "profiles: читать" on profiles for select using (true);

create policy "tutors: видны опубликованные" on tutor_profiles for select
  using (is_published or auth.uid() = id);
create policy "tutors: правит только себя" on tutor_profiles for update
  using (auth.uid() = id) with check (auth.uid() = id);
-- Рейтинг нельзя подменить вручную: обновлять можно только поля анкеты
revoke update on tutor_profiles from authenticated;
grant update (headline, bio, subjects, price_per_hour, photos, is_published, updated_at) on tutor_profiles to authenticated;

create policy "lessons: видят участники" on lessons for select
  using (auth.uid() = student_id or auth.uid() = tutor_id);
create policy "lessons: ученик записывается" on lessons for insert
  with check (auth.uid() = student_id and status = 'scheduled');
create policy "lessons: репетитор отмечает итог" on lessons for update
  using (auth.uid() = tutor_id) with check (auth.uid() = tutor_id);

create policy "reviews: читают все" on reviews for select using (true);
-- Оставить отзыв можно только после завершённого урока с этим репетитором
create policy "reviews: после урока" on reviews for insert
  with check (
    auth.uid() = student_id and exists (
      select 1 from lessons l
      where l.tutor_id = reviews.tutor_id and l.student_id = auth.uid() and l.status = 'completed'
    )
  );
create policy "reviews: правит автор" on reviews for update
  using (auth.uid() = student_id) with check (auth.uid() = student_id);
