import { notFound } from 'next/navigation';
import { supabaseServer } from '@/lib/supabase/server';
import { bookLesson } from '@/app/actions';
import { fmt } from '@/lib/time';

type Review = { rating: number; body: string; profiles: { full_name: string } | null };
const stars = (v: number) => '★'.repeat(Math.round(v)) + '☆'.repeat(5 - Math.round(v));

export default async function TutorPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ error?: string }> }) {
  const { id } = await params;
  const sp = await searchParams;
  const supabase = await supabaseServer();
  const { data: t } = await supabase
    .from('tutor_profiles')
    .select('*, profiles(full_name)')
    .eq('id', id)
    .eq('is_published', true)
    .maybeSingle();
  if (!t) notFound();

  const { data: reviews } = await supabase
    .from('reviews')
    .select('rating, body, profiles(full_name)')
    .eq('tutor_id', id)
    .order('created_at', { ascending: false })
    .limit(20);
  const { data: slots } = await supabase
    .from('availability')
    .select('id, starts_at')
    .eq('tutor_id', id)
    .gt('starts_at', new Date().toISOString())
    .order('starts_at')
    .limit(30);
  const list = (reviews ?? []) as unknown as Review[];

  return (
    <main className="wrap">
      <section className="card hero">
        <div>
          <h1>{t.profiles?.full_name}</h1>
          <p className="muted">{t.headline}</p>
          <p><span className="stars">{stars(t.rating_avg)}</span> {t.rating_avg} · {t.rating_count} отзывов</p>
          <div className="tags">{t.subjects.map((s: string) => <span key={s}>{s}</span>)}</div>
        </div>
        <div className="buy"><p className="price">{t.price_per_hour} {t.currency} / час</p></div>
      </section>

      {t.photos.length > 0 && (
        <section className="photos">{t.photos.map((p: string) => <img key={p} src={p} alt="" />)}</section>
      )}

      <section className="card">
        <h2>О себе</h2>
        <p style={{ whiteSpace: 'pre-line', margin: 0 }}>{t.bio || 'Описание пока не добавлено.'}</p>
      </section>

      <section className="card">
        <h2>Свободное время</h2>
        {sp.error && <p className="err">{sp.error}</p>}
        {(slots ?? []).length === 0 && <p className="muted">Свободных слотов пока нет.</p>}
        <div className="slots">
          {(slots ?? []).map((s) => (
            <form action={bookLesson} key={s.id}>
              <input type="hidden" name="tutor_id" value={id} />
              <input type="hidden" name="starts_at" value={s.starts_at} />
              <button className="ghost">{fmt(s.starts_at)}</button>
            </form>
          ))}
        </div>
        <p className="muted">Записаться могут ученики. Если вы не вошли, сначала войдите в аккаунт.</p>
      </section>

      <section>
        <h2>Отзывы</h2>
        {list.length === 0 && <p className="muted">Отзывов пока нет.</p>}
        {list.map((r, i) => (
          <article className="card review" key={i}>
            <p><span className="stars">{stars(r.rating)}</span> <strong>{r.profiles?.full_name}</strong></p>
            {r.body && <p>{r.body}</p>}
          </article>
        ))}
      </section>
    </main>
  );
}
