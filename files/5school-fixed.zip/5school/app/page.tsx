import { supabaseServer } from '@/lib/supabase/server';

type Row = { id: string; headline: string; subjects: string[]; price_per_hour: number; currency: string; rating_avg: number; rating_count: number; photos: string[]; profiles: { full_name: string } | null };
const stars = (v: number) => '★'.repeat(Math.round(v)) + '☆'.repeat(5 - Math.round(v));

export default async function Home() {
  const supabase = await supabaseServer();
  const { data } = await supabase
    .from('tutor_profiles')
    .select('id, headline, subjects, price_per_hour, currency, rating_avg, rating_count, photos, profiles(full_name)')
    .eq('is_published', true)
    .order('rating_avg', { ascending: false });
  const tutors = (data ?? []) as unknown as Row[];

  return (
    <main className="wrap">
      <h1>Репетиторы</h1>
      {tutors.length === 0 && <p className="muted">Пока нет опубликованных анкет.</p>}
      <div className="grid">
        {tutors.map((t) => (
          <a className="card tutor" href={`/tutors/${t.id}`} key={t.id}>
            {t.photos[0] ? <img src={t.photos[0]} alt="" /> : <div className="ph" />}
            <h3>{t.profiles?.full_name}</h3>
            <p className="muted">{t.headline}</p>
            <div className="tags">{t.subjects.map((s) => <span key={s}>{s}</span>)}</div>
            <p><span className="stars">{stars(t.rating_avg)}</span> <span className="muted">{t.rating_count} отзывов</span></p>
            <p className="price">{t.price_per_hour} {t.currency} / час</p>
          </a>
        ))}
      </div>
    </main>
  );
}
