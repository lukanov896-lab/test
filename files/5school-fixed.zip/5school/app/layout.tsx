import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = { title: '5school — репетиторы', description: 'Занятия с репетиторами: отзывы, цены, расписание' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru">
      <head>
        <link rel="preconnect" href="https://fonts.gstatic.com" />
        <link href="https://fonts.googleapis.com/css2?family=Golos+Text:wght@400;500;600&family=Unbounded:wght@500;600&display=swap" rel="stylesheet" />
      </head>
      <body>
        <header className="top">
          <a className="brand" href="/">5school</a>
          <a href="/dashboard">Кабинет</a>
        </header>
        {children}
      </body>
    </html>
  );
}
