import { redirect } from 'next/navigation';
import { supabaseServer } from '@/lib/supabase/server';
import { saveTutorProfile, addPhoto, removePhoto } from '@/app/actions';

export default async function TutorProfilePage({ searchParams }: { searchParams: Promise<{ saved?: string; error?: string }> }) {
  const sp = await searchParams;
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  const { data: t } = await supabase.from('tutor_profiles').select('*').eq('id', user.id).maybeSingle();
  if (!t) redirect('/dashboard');

  return (
    <main className="wrap narrow">
      <h1>Моя анкета</h1>
      {sp.saved && <p className="notice">Сохранено.</p>}
      {sp.error && <p className="err">{sp.error === 'photo' ? 'Не удалось загрузить фото. Нужен файл-картинка до 5 МБ.' : 'Не удалось сохранить. Попробуйте ещё раз.'}</p>}

      <form action={saveTutorProfile} className="card">
        <label>Заголовок<input name="headline" maxLength={120} defaultValue={t.headline} /></label>
        <label>О себе<textarea name="bio" rows={6} maxLength={2000} defaultValue={t.bio} /></label>
        <label>Предметы (через запятую)<input name="subjects" defaultValue={t.subjects.join(', ')} /></label>
        <label>Цена за час, {t.currency}<input name="price" type="number" min={0} defaultValue={t.price_per_hour} /></label>
        <label className="check"><input type="checkbox" name="is_published" defaultChecked={t.is_published} /> Показывать в каталоге</label>
        <button className="primary">Сохранить</button>
      </form>

      <section className="card">
        <h2>Фото</h2>
        <div className="photos">
          {t.photos.map((p: string) => (
            <form action={removePhoto} key={p}>
              <img src={p} alt="" />
              <input type="hidden" name="url" value={p} />
              <button className="ghost">Удалить</button>
            </form>
          ))}
        </div>
        {t.photos.length < 10 && (
          <form action={addPhoto} className="slot">
            <input type="file" name="photo" accept="image/*" required />
            <button className="primary">Загрузить</button>
          </form>
        )}
      </section>
    </main>
  );
}
