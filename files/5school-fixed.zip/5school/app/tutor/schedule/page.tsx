import { redirect } from 'next/navigation';
import { supabaseServer } from '@/lib/supabase/server';
import { deleteSlot, completeLesson, saveLessonPlan, addHomework, deleteHomework, checkHomework } from '@/app/actions';
import { fmt } from '@/lib/time';
import { SlotInput } from './slot-input';

const HW: Record<string, string> = { assigned: 'не сдано', submitted: 'ждёт проверки', checked: 'проверено' };

export default async function SchedulePage({ searchParams }: { searchParams: Promise<{ saved?: string; error?: string }> }) {
  const sp = await searchParams;
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  const { data: slots } = await supabase.from('availability').select('id, starts_at').eq('tutor_id', user.id).order('starts_at');
  const { data: lessons } = await supabase.from('lessons').select('id, starts_at, status, plan, profiles(full_name)').eq('tutor_id', user.id).order('starts_at');
  const ids = (lessons ?? []).map((l: any) => l.id);
  const { data: hw } = ids.length
    ? await supabase.from('homework').select('id, lesson_id, title, body, status, answer, feedback').in('lesson_id', ids).order('created_at')
    : { data: [] as any[] };

  return (
    <main className="wrap narrow">
      <h1>Расписание</h1>
      {sp.saved && <p className="notice">Сохранено.</p>}
      {sp.error && <p className="err">Что-то пошло не так. Проверьте данные и попробуйте снова.</p>}

      <section className="card">
        <h2>Свободное время</h2>
        <SlotInput />
        {(slots ?? []).length === 0 && <p className="muted">Слотов пока нет.</p>}
        <ul className="list">
          {(slots ?? []).map((s: any) => (
            <li key={s.id}>
              <span>{fmt(s.starts_at)}</span>
              <form action={deleteSlot}><input type="hidden" name="id" value={s.id} /><button className="ghost">Убрать</button></form>
            </li>
          ))}
        </ul>
      </section>

      <section className="card">
        <h2>Уроки</h2>
        {(lessons ?? []).length === 0 && <p className="muted">Записей пока нет.</p>}
        <ul className="list">
          {(lessons ?? []).map((l: any) => (
            <li className="lesson" key={l.id}>
              <div className="row">
                <span>{fmt(l.starts_at)} · {l.profiles?.full_name}</span>
                {l.status === 'scheduled'
                  ? <form action={completeLesson}><input type="hidden" name="id" value={l.id} /><button className="ghost">Урок прошёл</button></form>
                  : <span className="muted">{l.status === 'completed' ? 'Проведён' : 'Отменён'}</span>}
              </div>

              <form action={saveLessonPlan}>
                <input type="hidden" name="id" value={l.id} />
                <label>План урока<textarea name="plan" rows={3} maxLength={4000} defaultValue={l.plan} /></label>
                <button className="ghost">Сохранить план</button>
              </form>

              {(hw ?? []).filter((h: any) => h.lesson_id === l.id).map((h: any) => (
                <div className="hw" key={h.id}>
                  <p><strong>{h.title}</strong> · {HW[h.status]}</p>
                  {h.body && <p className="muted">{h.body}</p>}
                  {h.status !== 'assigned' && <p>Ответ: {h.answer}</p>}
                  {h.status === 'submitted' && (
                    <form action={checkHomework}>
                      <input type="hidden" name="id" value={h.id} />
                      <label>Комментарий<textarea name="feedback" rows={2} maxLength={4000} /></label>
                      <button className="ghost">Проверено</button>
                    </form>
                  )}
                  {h.status === 'checked' && h.feedback && <p>Комментарий: {h.feedback}</p>}
                  <form action={deleteHomework}><input type="hidden" name="id" value={h.id} /><button className="ghost">Удалить</button></form>
                </div>
              ))}

              <form action={addHomework}>
                <input type="hidden" name="lesson_id" value={l.id} />
                <label>Домашка<input name="title" required maxLength={120} placeholder="Например: задачи 1–5" /></label>
                <label>Подробности<textarea name="body" rows={2} maxLength={4000} /></label>
                <button className="ghost">Задать</button>
              </form>
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}
