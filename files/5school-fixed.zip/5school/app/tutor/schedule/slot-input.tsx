'use client';
import { useState } from 'react';
import { addSlot } from '@/app/actions';

// Переводит локальное время в ISO-строку, чтобы сервер не угадывал часовой пояс
export function SlotInput() {
  const [iso, setIso] = useState('');
  return (
    <form action={addSlot} className="slot">
      <input
        type="datetime-local"
        required
        onChange={(e) => setIso(e.target.value ? new Date(e.target.value).toISOString() : '')}
      />
      <input type="hidden" name="starts_at" value={iso} />
      <button className="primary" disabled={!iso}>Добавить</button>
    </form>
  );
}
