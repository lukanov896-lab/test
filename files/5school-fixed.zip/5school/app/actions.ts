'use server';
import { randomUUID } from 'crypto';
import { redirect } from 'next/navigation';
import { supabaseServer } from '@/lib/supabase/server';

const LOGIN_ERROR = 'Почта или пароль не подходят.';

export async function signUp(formData: FormData) {
  const supabase = await supabaseServer();
  const role = formData.get('role') === 'tutor' ? 'tutor' : 'student';
  const { data, error } = await supabase.auth.signUp({
    email: String(formData.get('email') ?? ''),
    password: String(formData.get('password') ?? ''),
    options: {
      data: { full_name: String(formData.get('name') ?? '').slice(0, 60), role },
      emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/auth/callback`,
    },
  });
  if (error) redirect(`/register?error=${encodeURIComponent('Не удалось создать аккаунт. Возможно, он уже есть.')}`);
  if (!data.session) redirect('/login?message=check-email');
  redirect('/dashboard');
}

export async function signIn(formData: FormData) {
  const supabase = await supabaseServer();
  const { error } = await supabase.auth.signInWithPassword({
    email: String(formData.get('email') ?? ''),
    password: String(formData.get('password') ?? ''),
  });
  if (error) {
    const msg = error.message.toLowerCase().includes('not confirmed') ? 'Подтвердите почту: ссылка уже в письме.' : LOGIN_ERROR;
    redirect(`/login?error=${encodeURIComponent(msg)}`);
  }
  redirect('/dashboard');
}

export async function signOut() {
  const supabase = await supabaseServer();
  await supabase.auth.signOut();
  redirect('/');
}

export async function saveTutorProfile(formData: FormData) {
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  const subjects = String(formData.get('subjects') ?? '').split(',').map((s) => s.trim()).filter(Boolean).slice(0, 10);
  const { error } = await supabase.from('tutor_profiles').update({
    headline: String(formData.get('headline') ?? '').slice(0, 120),
    bio: String(formData.get('bio') ?? '').slice(0, 2000),
    subjects,
    price_per_hour: Math.max(0, Math.round(Number(formData.get('price')) || 0)),
    is_published: formData.get('is_published') === 'on',
    updated_at: new Date().toISOString(),
  }).eq('id', user.id);
  if (error) redirect('/tutor/profile?error=1');
  redirect('/tutor/profile?saved=1');
}

export async function addPhoto(formData: FormData) {
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  const file = formData.get('photo');
  if (!(file instanceof File) || file.size === 0 || file.size > 4 * 1024 * 1024 || !file.type.startsWith('image/')) {
    redirect('/tutor/profile?error=photo');
  }
  const path = `${user.id}/${randomUUID()}`;
  const { error: upErr } = await supabase.storage.from('tutor-photos').upload(path, file, { contentType: file.type });
  if (upErr) redirect('/tutor/profile?error=photo');
  const { data: pub } = supabase.storage.from('tutor-photos').getPublicUrl(path);
  const { data: t } = await supabase.from('tutor_profiles').select('photos').eq('id', user.id).single();
  const photos = [...(t?.photos ?? []), pub.publicUrl].slice(0, 10);
  await supabase.from('tutor_profiles').update({ photos }).eq('id', user.id);
  redirect('/tutor/profile?saved=1');
}

export async function removePhoto(formData: FormData) {
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  const url = String(formData.get('url') ?? '');
  const path = url.split('/tutor-photos/')[1];
  if (path && path.startsWith(`${user.id}/`)) {
    await supabase.storage.from('tutor-photos').remove([decodeURIComponent(path)]);
  }
  const { data: t } = await supabase.from('tutor_profiles').select('photos').eq('id', user.id).single();
  await supabase.from('tutor_profiles').update({ photos: (t?.photos ?? []).filter((p: string) => p !== url) }).eq('id', user.id);
  redirect('/tutor/profile?saved=1');
}

export async function addSlot(formData: FormData) {
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  const { error } = await supabase.from('availability').insert({ tutor_id: user.id, starts_at: String(formData.get('starts_at') ?? '') });
  redirect(error ? '/tutor/schedule?error=1' : '/tutor/schedule?saved=1');
}

export async function deleteSlot(formData: FormData) {
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  await supabase.from('availability').delete().eq('id', String(formData.get('id'))).eq('tutor_id', user.id);
  redirect('/tutor/schedule?saved=1');
}

export async function completeLesson(formData: FormData) {
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  await supabase.from('lessons').update({ status: 'completed' }).eq('id', String(formData.get('id'))).eq('tutor_id', user.id);
  redirect('/tutor/schedule?saved=1');
}

export async function bookLesson(formData: FormData) {
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  const tutorId = String(formData.get('tutor_id') ?? '');
  const { error } = await supabase.rpc('book_lesson', { p_tutor: tutorId, p_starts: String(formData.get('starts_at') ?? '') });
  if (error) redirect(`/tutors/${tutorId}?error=${encodeURIComponent('Этот слот уже занят или запись недоступна.')}`);
  redirect('/dashboard?booked=1');
}

export async function saveLessonPlan(formData: FormData) {
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  await supabase.from('lessons')
    .update({ plan: String(formData.get('plan') ?? '').slice(0, 4000) })
    .eq('id', String(formData.get('id'))).eq('tutor_id', user.id);
  redirect('/tutor/schedule?saved=1');
}

export async function addHomework(formData: FormData) {
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  const { error } = await supabase.from('homework').insert({
    lesson_id: String(formData.get('lesson_id') ?? ''),
    title: String(formData.get('title') ?? '').trim().slice(0, 120),
    body: String(formData.get('body') ?? '').slice(0, 4000),
  });
  redirect(error ? '/tutor/schedule?error=1' : '/tutor/schedule?saved=1');
}

export async function deleteHomework(formData: FormData) {
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  await supabase.from('homework').delete().eq('id', String(formData.get('id')));
  redirect('/tutor/schedule?saved=1');
}

export async function submitHomework(formData: FormData) {
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  const { error } = await supabase.rpc('submit_homework', {
    p_id: String(formData.get('id') ?? ''),
    p_answer: String(formData.get('answer') ?? '').slice(0, 4000),
  });
  redirect(error ? '/dashboard?error=1' : '/dashboard?saved=1');
}

export async function checkHomework(formData: FormData) {
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  const { error } = await supabase.rpc('check_homework', {
    p_id: String(formData.get('id') ?? ''),
    p_feedback: String(formData.get('feedback') ?? '').slice(0, 4000),
  });
  redirect(error ? '/tutor/schedule?error=1' : '/tutor/schedule?saved=1');
}

// Отзыв: только после завершённого урока (проверяет база). Повторный отзыв обновляет старый.
export async function saveReview(formData: FormData) {
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  const rating = Math.min(5, Math.max(1, Math.round(Number(formData.get('rating')) || 0)));
  const { error } = await supabase.from('reviews').upsert(
    {
      tutor_id: String(formData.get('tutor_id') ?? ''),
      student_id: user.id,
      rating,
      body: String(formData.get('body') ?? '').slice(0, 1000),
    },
    { onConflict: 'tutor_id,student_id' },
  );
  redirect(error ? '/dashboard?error=1' : '/dashboard?saved=1');
}
