import { redirect } from 'next/navigation';
import { supabaseServer } from '@/lib/supabase/server';
import { signOut, submitHomework, saveReview } from '@/app/actions';
import { fmt } from '@/lib/time';

const STATUS: Record<string, string> = { scheduled: 'запланирован', completed: 'проведён', cancelled: 'отменён' };

export default async function Dashboard({ searchParams }: { searchParams: Promise<{ booked?: string; saved?: string; error?: string }> }) {
  const sp = await searchParams;
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  const { data: p } = await supabase.from('profiles').select('full_name, role').eq('id', user.id).single();
  const isTutor = p?.role === 'tutor';

  const { data: lessons } = await supabase
    .from('lessons')
    .select('id, tutor_id, starts_at, status, plan, profiles(full_name), tutor_profiles(profiles(full_name))')
    .or(`student_id.eq.${user.id},tutor_id.eq.${user.id}`)
    .order('starts_at');
  const list = (lessons ?? []) as any[];

  const { data: hw } = isTutor
    ? { data: [] as any[] }
    : await supabase.from('homework').select('id, title, body, status, feedback').order('created_at');
  const { data: myReviews } = isTutor
    ? { data: [] as any[] }
    : await supabase.from('reviews').select('tutor_id, rating, body').eq('student_id', user.id);
  const reviewMap = new Map((myReviews ?? []).map((r: any): [string, any] => [r.tutor_id, r]));

  // Репетиторы, у которых был завершённый урок: им можно оставить отзыв
  const toReview = new Map<string, string>();
  list.filter((l) => l.status === 'completed').forEach((l) => {
    toReview.set(l.tutor_id, l.tutor_profiles?.profiles?.full_name ?? 'Репетитор');
  });

  return (
    <main className="wrap">
      <h1>Здравствуйте, {p?.full_name}</h1>
      <p className="muted">{isTutor ? 'Кабинет репетитора' : 'Кабинет ученика'}</p>
      {sp.booked && <p className="notice">Урок записан.</p>}
      {sp.saved && <p className="notice">Сохранено.</p>}
      {sp.error && <p className="err">Не получилось сохранить. Попробуйте ещё раз.</p>}

      <div className="grid">
        {isTutor ? (
          <>
            <a className="card" href="/tutor/profile"><h3>Моя анкета</h3><p className="muted">Предметы, цена, фото и описание.</p></a>
            <a className="card" href="/tutor/schedule"><h3>Расписание</h3><p className="muted">Уроки, планы и домашка.</p></a>
          </>
        ) : (
          <a className="card" href="/"><h3>Найти репетитора</h3><p className="muted">Каталог с рейтингом и отзывами.</p></a>
        )}
      </div>

      <section className="card">
        <h2>Мои уроки</h2>
        {list.length === 0 && <p className="muted">Уроков пока нет.</p>}
        <ul className="list">
          {list.map((l) => (
            <li key={l.id}>
              <span>{fmt(l.starts_at)}</span>
              <span className="muted">
                {isTutor ? l.profiles?.full_name : l.tutor_profiles?.profiles?.full_name} · {STATUS[l.status] ?? l.status}
              </span>
            </li>
          ))}
        </ul>
      </section>

      {!isTutor && list.some((l) => l.plan) && (
        <section className="card">
          <h2>План уроков</h2>
          {list.filter((l) => l.plan).map((l) => (
            <div className="hw" key={l.id}>
              <p><strong>{fmt(l.starts_at)}</strong></p>
              <p>{l.plan}</p>
            </div>
          ))}
        </section>
      )}

      {!isTutor && (
        <section className="card">
          <h2>Домашка</h2>
          {(hw ?? []).length === 0 && <p className="muted">Домашних заданий пока нет.</p>}
          {(hw ?? []).map((h: any) => (
            <div className="hw" key={h.id}>
              <p><strong>{h.title}</strong></p>
              {h.body && <p className="muted">{h.body}</p>}
              {h.status === 'assigned' && (
                <form action={submitHomework}>
                  <input type="hidden" name="id" value={h.id} />
                  <label>Ваш ответ<textarea name="answer" rows={3} required maxLength={4000} /></label>
                  <button className="primary">Отправить</button>
                </form>
              )}
              {h.status === 'submitted' && <p className="muted">Отправлено, ждёт проверки.</p>}
              {h.status === 'checked' && <p>Проверено.{h.feedback && ` Комментарий: ${h.feedback}`}</p>}
            </div>
          ))}
        </section>
      )}

      {!isTutor && (
        <section className="card">
          <h2>Отзывы</h2>
          {toReview.size === 0 && <p className="muted">Оставить отзыв можно после завершённого урока.</p>}
          {[...toReview.entries()].map(([tutorId, name]) => {
            const mine = reviewMap.get(tutorId);
            return (
              <form action={saveReview} className="hw" key={tutorId}>
                <input type="hidden" name="tutor_id" value={tutorId} />
                <p><strong>{name}</strong>{mine && <span className="muted"> · отзыв сохранён</span>}</p>
                <label>Оценка
                  <select name="rating" defaultValue={mine?.rating ?? 5}>
                    {[5, 4, 3, 2, 1].map((n) => <option key={n} value={n}>{n}</option>)}
                  </select>
                </label>
                <label>Комментарий<textarea name="body" rows={2} maxLength={1000} defaultValue={mine?.body ?? ''} /></label>
                <button className="primary">Сохранить отзыв</button>
              </form>
            );
          })}
        </section>
      )}

      <form action={signOut}><button className="ghost">Выйти</button></form>
    </main>
  );
}
