import { signUp } from '@/app/actions';

export default async function RegisterPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const sp = await searchParams;
  return (
    <main className="wrap narrow">
      <h1>Регистрация</h1>
      {sp.error && <p className="err">{sp.error}</p>}
      <form action={signUp} className="card">
        <label>Имя<input name="name" required maxLength={60} /></label>
        <div className="roles">
          <label className="role"><input type="radio" name="role" value="student" defaultChecked /><span><b>Ученик</b><small>Ищу репетитора</small></span></label>
          <label className="role"><input type="radio" name="role" value="tutor" /><span><b>Репетитор</b><small>Веду уроки</small></span></label>
        </div>
        <label>Почта<input name="email" type="email" required /></label>
        <label>Пароль<input name="password" type="password" minLength={6} required /></label>
        <button className="primary">Создать аккаунт</button>
      </form>
      <p className="muted">Уже есть аккаунт? <a href="/login">Войти</a></p>
    </main>
  );
}
