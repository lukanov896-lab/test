import { signIn } from '@/app/actions';

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ error?: string; message?: string }> }) {
  const sp = await searchParams;
  return (
    <main className="wrap narrow">
      <h1>Вход в 5school</h1>
      {sp.message === 'check-email' && <p className="notice">Письмо отправлено. Подтвердите почту и войдите.</p>}
      {sp.error && <p className="err">{sp.error}</p>}
      <form action={signIn} className="card">
        <label>Почта<input name="email" type="email" required /></label>
        <label>Пароль<input name="password" type="password" required /></label>
        <button className="primary">Войти</button>
      </form>
      <p className="muted">Нет аккаунта? <a href="/register">Регистрация</a></p>
    </main>
  );
}
