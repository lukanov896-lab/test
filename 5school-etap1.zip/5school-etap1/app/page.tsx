import { supabaseServer } from '@/lib/supabase/server';
import { hasSessionCookie } from '@/lib/session';
import { DIRECTIONS, POPULAR_SUBJECTS } from '@/lib/directions';

type Row = {
  id: string;
  headline: string;
  kind: string;
  subjects: string[];
  price_per_hour: number;
  rating_avg: number;
  rating_count: number;
  photos: string[];
  profiles: { full_name: string } | null;
};

const stars = (v: number) => '★'.repeat(Math.round(v)) + '☆'.repeat(5 - Math.round(v));

export default async function Home({ searchParams }: { searchParams: Promise<{ q?: string; kind?: string; max?: string; sort?: string }> }) {
  const sp = await searchParams;
  const signedIn = await hasSessionCookie();
  const supabase = await supabaseServer();
  const { data } = await supabase
    .from('tutor_profiles')
    .select('id, headline, kind, subjects, price_per_hour, rating_avg, rating_count, photos, profiles(full_name)')
    .eq('is_published', true)
    .eq('is_approved', true);
  const all = (data ?? []) as unknown as Row[];

  // Фильтры в коде: предметы вводятся свободным текстом, регистр и написание разные
  const q = (sp.q ?? '').trim().toLowerCase();
  const kind = DIRECTIONS.some((d) => d.value === sp.kind) ? (sp.kind as string) : '';
  const max = Number(sp.max);
  const sort = sp.sort === 'price' ? 'price' : 'rating';

  let tutors = all;
  if (q) tutors = tutors.filter((t) => [t.profiles?.full_name ?? '', t.headline, ...t.subjects].some((s) => s.toLowerCase().includes(q)));
  if (kind) tutors = tutors.filter((t) => t.kind === kind);
  if (max > 0) tutors = tutors.filter((t) => t.price_per_hour <= max);
  tutors = [...tutors].sort(
    sort === 'price'
      ? (a, b) => a.price_per_hour - b.price_per_hour
      : (a, b) => b.rating_avg - a.rating_avg || b.rating_count - a.rating_count,
  );

  return (
    <main className="wrap">
      <section className="home-hero">
        <p className="chip">Школа, вуз, экзамены и другие специалисты в одном месте</p>
        <h1 className="home-title">Репетиторы</h1>
        <form className="filters" method="get">
          <input name="q" placeholder="Предмет или имя" defaultValue={sp.q ?? ''} />
          <select name="kind" defaultValue={kind}>
            <option value="">Все направления</option>
            {DIRECTIONS.map((d) => <option key={d.value} value={d.value}>{d.label}</option>)}
          </select>
          <input name="max" type="number" min={0} placeholder="Цена до, ₽" defaultValue={sp.max ?? ''} />
          <select name="sort" defaultValue={sort}>
            <option value="rating">По рейтингу</option>
            <option value="price">Сначала дешёвые</option>
          </select>
          <button className="primary">Найти</button>
        </form>
        <div className="chips">
          {POPULAR_SUBJECTS.map((s) => (
            <a key={s} href={`/?q=${encodeURIComponent(s)}`} className={sp.q === s ? 'on' : undefined}>{s}</a>
          ))}
        </div>
        {!signedIn && <p className="hero-cta"><a className="cta" href="/register">Стать репетитором</a></p>}
      </section>

      {all.length === 0 && <p className="muted">Пока нет опубликованных анкет.</p>}
      {all.length > 0 && tutors.length === 0 && <p className="muted">Ничего не найдено. Попробуйте изменить запрос.</p>}

      <div className="grid">
        {tutors.map((t) => (
          <a className="card tutor" href={`/tutors/${t.id}`} key={t.id}>
            {t.photos[0] ? <img src={t.photos[0]} alt="" /> : <div className="ph" />}
            <h3>{t.profiles?.full_name}</h3>
            <p className="muted">{t.headline}</p>
            <div className="tags">
              {t.subjects.slice(0, 4).map((s) => <span key={s}>{s}</span>)}
              {t.subjects.length > 4 && <span>+{t.subjects.length - 4}</span>}
            </div>
            <p><span className="stars">{stars(t.rating_avg)}</span> <span className="muted">{t.rating_count} отзывов</span></p>
            <p className="price">{t.price_per_hour.toLocaleString('ru-RU')}&nbsp;₽ / час</p>
          </a>
        ))}
      </div>
    </main>
  );
}
