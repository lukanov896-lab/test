-- 5school, этап 7: направления и рубли. Выполнить ПОСЛЕ schema_stage6.sql.
-- Файл можно запускать повторно.

-- 1. Направление репетитора: шесть значений из lib/directions.ts
alter table tutor_profiles add column if not exists kind text not null default 'other'
  check (kind in ('school', 'university', 'exam', 'language', 'specialist', 'other'));

-- 2. Цены в рублях
alter table tutor_profiles alter column currency set default 'RUB';
update tutor_profiles set currency = 'RUB' where currency = 'EUR';

-- 3. Репетитор может менять направление в своей анкете
revoke update on tutor_profiles from authenticated;
grant update (headline, bio, subjects, price_per_hour, is_published, updated_at, kind) on tutor_profiles to authenticated;
